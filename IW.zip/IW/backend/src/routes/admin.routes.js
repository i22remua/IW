// src/routes/reserva.routes.js
const express = require('express');
const router = express.Router();
const admincontroller = require('../controllers/admin.controller');

// Rutas para reservas
router.post('/', admincontroller.registrarRestaurante);
router.patch('/:id', admincontroller.editarRestaurante);
router.post('/login', admincontroller.loginAdmin);

module.exports = router;
