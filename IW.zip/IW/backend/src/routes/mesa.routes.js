// src/routes/mesa.routes.js
const express = require('express');
const router = express.Router();
const mesaController = require('../controllers/mesa.controller');

// Rutas para mesas
router.post('/', mesaController.crearMesa);
router.get('/', mesaController.obtenerMesas);
router.get('/:id', mesaController.obtenerMesaPorId);
router.put('/:id', mesaController.actualizarMesa);
router.delete('/:id', mesaController.eliminarMesa);

module.exports = router;
