// src/routes/reserva.routes.js
const express = require('express');
const router = express.Router();
const reservaController = require('../controllers/reserva.controller');

// Rutas para reservas
router.post('/', reservaController.crearReserva);
router.put('/:id', reservaController.actualizarReserva);
router.delete('/:id', reservaController.eliminarReserva);
router.get('/', reservaController.obtenerReservas); // ✅ esta línea debe existir


module.exports = router;
