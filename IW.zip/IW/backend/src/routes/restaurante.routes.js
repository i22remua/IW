const express = require('express');
const router = express.Router();
const restauranteController = require('../controllers/restaurante.controller');

// Rutas para restaurantes
router.get('/', restauranteController.obtenerRestaurantes);
router.post('/', restauranteController.crearRestaurante);
router.get('/:id', restauranteController.obtenerRestaurantePorId);
router.put('/:id', restauranteController.editarRestaurante);
router.delete('/:id', restauranteController.eliminarRestaurante);
router.get('/cercanos', restauranteController.obtenerRestaurantesCercanos);

module.exports = router;
