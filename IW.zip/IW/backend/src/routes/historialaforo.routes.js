const express = require('express');
const router = express.Router();
const historialaforoController = require('../controllers/historialaforo.controller');

// Solo esta ruta funcionará, porque es la única que has definido
router.get('/disponible', historialaforoController.verAforoDisponible);

module.exports = router;
