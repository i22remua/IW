const express = require('express');
const router = express.Router();
const valoracionController = require('../controllers/valoracion.controller');

router.post('/', valoracionController.crearValoracion);
router.get('/', valoracionController.obtenerValoraciones);
router.get('/:id', valoracionController.obtenerValoracionPorId);
router.get('/restaurante/:restaurante_id', valoracionController.obtenerValoracionesPorRestaurante);
router.put('/:id', valoracionController.actualizarValoracion);
router.delete('/:id', valoracionController.eliminarValoracion);
router.post('/restaurante/:restaurante_id/usuario/:usuario_id', valoracionController.valorarRestaurante);
module.exports = router;
