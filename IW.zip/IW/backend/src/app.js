require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path'); // ← NECESARIO para usar path.join
const app = express();

// Middleware primero
app.use(express.json());
app.use(cors());

// ✅ PRIMERO: Redirige / al QR manualmente
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'qr.html'));
});

// ✅ LUEGO: Servir estáticos normalmente
app.use(express.static(path.join(__dirname, 'public')));

// Rutas API (pueden ir después sin problema)
app.use('/api/usuarios', require('./routes/usuario.routes'));
app.use('/api/valoraciones', require('./routes/valoracion.routes'));
app.use('/api/aforo', require('./routes/historialaforo.routes'));
app.use('/api/mesas', require('./routes/mesa.routes'));
app.use('/api/admin', require('./routes/admin.routes'));
app.use('/api/restaurantes', require('./routes/restaurante.routes'));
app.use('/api/reservas', require('./routes/reserva.routes'));

app.listen(3000, () => {
  console.log('🟢 Servidor escuchando en http://localhost:3000');
});
