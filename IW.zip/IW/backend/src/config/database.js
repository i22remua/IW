// src/config/database.js
const mysql = require('mysql2/promise');
require('dotenv').config();

async function connectWithRetry() {
    try {
        const pool = mysql.createPool({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            database: process.env.DB_NAME,
            waitForConnections: true,
            connectionLimit: 10,
            queueLimit: 0
        });

        // Verificar conexión
        const connection = await pool.getConnection();
        console.log("🟢 Conectado a la base de datos MySQL");
        connection.release();

        return pool;
    } catch (error) {
        console.error(`❌ Error al conectar a MySQL: ${error.message}`);
        console.log("🔁 Reintentando conexión en 3 segundos...");
        setTimeout(connectWithRetry, 3000);
    }
}

const db = connectWithRetry();

module.exports = db;
