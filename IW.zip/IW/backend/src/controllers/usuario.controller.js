const mysql = require('mysql2/promise');
require('dotenv').config();

// Conexión a la base de datos
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});


// Valorar restaurante
exports.valorarRestaurante = async (req, res) => {
    try {
        const { cliente_id, restaurante_id, puntuacion, comentario, fecha } = req.body;

        const [cliente] = await db.query('SELECT * FROM clientes WHERE id = ?', [cliente_id]);
        if (cliente.length === 0) {
            return res.status(403).json({ mensaje: 'Acceso no autorizado.' });
        }

        if (!restaurante_id || !puntuacion || puntuacion < 1 || puntuacion > 5 || !fecha) {
            return res.status(400).json({ mensaje: 'Datos de valoración inválidos.' });
        }

        await db.query(
            'INSERT INTO opiniones (restaurante_id, cliente_id, puntuacion, comentario, fecha) VALUES (?, ?, ?, ?, ?)',
            [restaurante_id, cliente_id, puntuacion, comentario, fecha]
        );

        res.status(201).json({ mensaje: 'Valoración registrada con éxito.' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al guardar la valoración.' });
    }
};
