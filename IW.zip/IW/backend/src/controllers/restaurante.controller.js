const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Obtener todos los restaurantes (CORRECTO)
exports.obtenerRestaurantes = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM restaurantes');
    res.status(200).json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Error al obtener restaurantes' });
  }
};

exports.obtenerRestaurantePorId = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query('SELECT * FROM restaurantes WHERE id = ?', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ mensaje: 'Restaurante no encontrado' });
    }

    res.status(200).json(rows[0]);
  } catch (error) {
    console.error('Error al obtener restaurante por ID:', error);
    res.status(500).json({ mensaje: 'Error al obtener el restaurante' });
  }
};


// Registrar nuevo restaurante
exports.crearRestaurante = async (req, res) => {
  try {
    const { nombre, direccion, tipo_comida, horario, aforo_max, historial } = req.body;

    if (!nombre || !direccion || !tipo_comida || !horario || !aforo_max) {
      return res.status(400).json({ mensaje: 'Faltan campos obligatorios' });
    }

    await db.query(
      'INSERT INTO restaurantes (nombre, direccion, tipo_comida, horario, aforo_max, historial) VALUES (?, ?, ?, ?, ?, ?)',
      [nombre, direccion, tipo_comida, horario, parseInt(aforo_max), historial || null]
    );

    res.status(201).json({ mensaje: 'Restaurante registrado con éxito' });
  } catch (error) {
    console.error('Error al registrar restaurante:', error);
    res.status(500).json({ mensaje: 'Error interno del servidor' });
  }
};


// Editar restaurante
exports.editarRestaurante = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, direccion, tipo_comida, horario, aforo_max } = req.body;

    if (!nombre || !direccion || !tipo_comida || !horario || !aforo_max) {
      return res.status(400).json({ mensaje: 'Faltan datos para editar' });
    }

    await db.query(
      'UPDATE restaurantes SET nombre = ?, direccion = ?, tipo_comida = ?, horario = ?, aforo_max = ? WHERE id = ?',
      [nombre, direccion, tipo_comida, horario, aforo_max, id]
    );

    res.status(200).json({ mensaje: 'Restaurante actualizado correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Error al actualizar restaurante' });
  }
};

exports.eliminarRestaurante = async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.query('DELETE FROM restaurantes WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ mensaje: 'Restaurante no encontrado o ya eliminado.' });
    }

    res.status(200).json({ mensaje: 'Restaurante eliminado correctamente.' });
  } catch (error) {
    console.error('Error al eliminar restaurante:', error);
    res.status(500).json({ mensaje: 'Error interno al eliminar restaurante.' });
  }
};

exports.obtenerRestaurantesCercanos = (req, res) => {
  const { lat, lon } = req.query;

  if (!lat || !lon) {
    return res.status(400).json({ error: 'Latitud y longitud requeridas' });
  }

  const query = `
    SELECT *, 
      (6371 * acos(
        cos(radians(?)) * cos(radians(latitud)) * 
        cos(radians(longitud) - radians(?)) + 
        sin(radians(?)) * sin(radians(latitud))
      )) AS distancia
    FROM restaurantes
    HAVING distancia < 10
    ORDER BY distancia ASC
    LIMIT 10;
  `;

  db.query(query, [lat, lon, lat], (err, results) => {
    if (err) {
      console.error('Error en la base de datos:', err);
      return res.status(500).json({ error: 'Error interno' });
    }

    if (results.length === 0) {
      return res.status(404).json({ mensaje: 'Restaurante no encontrado' });
    }

    res.json(results);
  });
};