const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

exports.loginAdmin = async (req, res) => {
  try {
    const { correo, contrasena } = req.body;

    const [rows] = await db.query(
      'SELECT * FROM administradores WHERE correo = ? AND contrasena = ?',
      [correo, contrasena]
    );

    if (rows.length === 0) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas' });
    }

    // ✅ Login exitoso
    res.status(200).json({ mensaje: 'Login exitoso', admin: rows[0] });
  } catch (error) {
    console.error('Error en loginAdmin:', error);
    res.status(500).json({ mensaje: 'Error al iniciar sesión' });
  }
};

exports.registrarRestaurante = async (datosRestaurante) => {
    const {
        nombre,
        direccion,
        tipo_comida,
        horario,
        aforo_max,
        aforo_actual = 0,
        historial = null
    } = datosRestaurante;

    // Validar campos requeridos
    if (!nombre || !direccion || !tipo_comida || !horario || !aforo_max) {
        throw new Error('Faltan campos obligatorios.');
    }

    try {
        const connection = await mysql.createConnection(dbConfig);

        // Verificar si ya existe un restaurante con el mismo nombre y dirección
        const [existente] = await connection.execute(
            'SELECT id FROM restaurantes WHERE nombre = ? AND direccion = ?',
            [nombre, direccion]
        );

        if (existente.length > 0) {
            throw new Error('Ya existe un restaurante con ese nombre y dirección.');
        }

        // Insertar en la base de datos
        await connection.execute(
            'INSERT INTO restaurantes (nombre, direccion, tipo_comida, horario, aforo_max, aforo_actual, historial) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [nombre, direccion, tipo_comida, horario, aforo_max, aforo_actual, historial]
        );

        await connection.end();
        return { success: true, mensaje: 'Restaurante registrado exitosamente.' };

    } catch (error) {
        console.error('Error al registrar restaurante:', error.message);
        throw error;
    }
};
exports.editarRestaurante = async (id, nuevaInfo) => {
    const { direccion, tipo_comida, horario, aforo_max } = nuevaInfo;

    if (!id || !direccion || !tipo_comida || !horario || !aforo_max) {
        throw new Error('Faltan datos para actualizar el restaurante.');
    }

    const connection = await mysql.createConnection(dbConfig);

    const [resultado] = await connection.execute(
        'SELECT id FROM restaurantes WHERE id = ?', [id]
    );

    if (resultado.length === 0) {
        throw new Error('Restaurante no encontrado.');
    }

    await connection.execute(
        'UPDATE restaurantes SET direccion = ?, tipo_comida = ?, horario = ?, aforo_max = ? WHERE id = ?',
        [direccion, tipo_comida, horario, aforo_max, id]
    );

    await connection.end();

    return { success: true, mensaje: 'Restaurante actualizado con éxito.' };
};