const mysql = require('mysql2/promise');
require('dotenv').config();

// Conexión a la base de datos
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Crear Valoración
exports.crearValoracion = async (req, res) => {
  try {
    const { restaurante_id, cliente_id, puntuacion, comentario } = req.body;

    // Validaciones básicas
    if (!restaurante_id || !cliente_id || !puntuacion) {
      return res.status(400).json({ mensaje: 'restaurante_id, cliente_id y puntuación son obligatorios.' });
    }

    if (puntuacion < 1 || puntuacion > 5) {
      return res.status(400).json({ mensaje: 'La puntuación debe estar entre 1 y 5.' });
    }

    // Verificar si el restaurante existe
    const [restaurante] = await db.query(
      'SELECT id FROM restaurantes WHERE id = ?',
      [restaurante_id]
    );
    if (restaurante.length === 0) {
      return res.status(404).json({ mensaje: 'No existe este id' });
    }

    // Verificar si el cliente existe
    const [cliente] = await db.query(
      'SELECT id FROM clientes WHERE id = ?',
      [cliente_id]
    );
    if (cliente.length === 0) {
      return res.status(404).json({ mensaje: 'No existe este id' });
    }

    // Insertar en la tabla opiniones
    const [result] = await db.query(
      'INSERT INTO opiniones (restaurante_id, cliente_id, puntuacion, comentario) VALUES (?, ?, ?, ?)',
      [restaurante_id, cliente_id, puntuacion, comentario || '']
    );

    // Respuesta exitosa
    res.status(201).json({
      id: result.insertId,
      restaurante_id,
      cliente_id,
      puntuacion,
      comentario: comentario || '',
      mensaje: 'Valoración guardada correctamente.'
    });

  } catch (error) {
    console.error('Error al guardar valoración:', error);
    res.status(500).json({ mensaje: 'Error interno al guardar la valoración.' });
  }
};


// Obtener todas las valoraciones
exports.obtenerValoraciones = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM opiniones ORDER BY fecha DESC');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ mensaje: 'Error al obtener valoraciones.' });
  }
};


// Obtener una valoración por ID
exports.obtenerValoracionPorId = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query('SELECT * FROM opiniones WHERE id = ?', [id]);

        if (rows.length === 0) {
            return res.status(404).json({ mensaje: 'Valoración no encontrada.' });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al obtener la valoración.' });
    }
};

// Actualizar una valoración
exports.actualizarValoracion = async (req, res) => {
    try {
        const { id } = req.params;
        const { puntuacion, comentario } = req.body;

        if (!puntuacion || puntuacion < 1 || puntuacion > 5) {
            return res.status(400).json({ mensaje: 'La puntuación debe estar entre 1 y 5.' });
        }

        await db.query(
            'UPDATE opiniones SET puntuacion = ?, comentario = ? WHERE id = ?',
            [puntuacion, comentario || '', id]
        );

        res.status(200).json({ mensaje: 'Valoración actualizada correctamente.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al actualizar la valoración.' });
    }
};

// Eliminar una valoración
exports.eliminarValoracion = async (req, res) => {
    try {
        const { id } = req.params;
        await db.query('DELETE FROM opiniones WHERE id = ?', [id]);
        res.status(200).json({ mensaje: 'Valoración eliminada correctamente.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al eliminar la valoración.' });
    }
};

// Obtener todas las valoraciones de un restaurante
exports.obtenerValoracionesPorRestaurante = async (req, res) => {
    try {
        const { restaurante_id } = req.params;

        const [rows] = await db.query(
            'SELECT * FROM opiniones WHERE restaurante_id = ?',
            [restaurante_id]
        );

        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error al obtener valoraciones del restaurante.' });
    }
};
// Valorar un restaurante
exports.valorarRestaurante = async (req, res) => {
    try {
        const cliente_id = req.session?.usuarioId; // Asume que el cliente ha iniciado sesión
        const { restaurante_id } = req.params;
        const { puntuacion, comentario } = req.body;

        // Verificación de acceso
        if (!cliente_id) {
            return res.status(401).json({ mensaje: 'Debe iniciar sesión para valorar.' });
        }

        // Validación de datos
        if (!puntuacion || puntuacion < 1 || puntuacion > 5) {
            return res.status(400).json({ mensaje: 'La puntuación debe estar entre 1 y 5.' });
        }

        // Insertar la opinión en la base de datos
        await db.query(
            'INSERT INTO opiniones (restaurante_id, cliente_id, puntuacion, comentario) VALUES (?, ?, ?, ?)',
            [restaurante_id, cliente_id, puntuacion, comentario || null]
        );

        res.status(201).json({ mensaje: 'Valoración registrada con éxito.' });

    } catch (error) {
        console.error('Error al valorar restaurante:', error);
        res.status(500).json({ mensaje: 'Error al valorar el restaurante.' });
    }
};

