const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});
// Función para ver aforo disponible en tiempo real

const Restaurante = require('../models/Restaurante');

exports.verAforoDisponible = async (req, res) => {
  try {
    const restauranteId = 1; // o req.params.id si estás usando parámetros
    const [result] = await db.query(
      'SELECT aforo_max - aforo_actual AS aforo_disponible FROM restaurantes WHERE id = ?',
      [restauranteId]
    );

    res.status(200).json(result[0]);
  } catch (error) {
    console.error('Error al consultar aforo:', error);
    res.status(500).json({ mensaje: 'Error al consultar aforo disponible' });
  }
};
