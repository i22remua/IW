const mysql = require('mysql2/promise');
require('dotenv').config();

// Configuración de la conexión a la base de datos
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Crear una nueva reserva
exports.crearReserva = async (req, res) => {
  try {
    const { nombre, email, telefono, fecha, hora, personas } = req.body;

    if (!nombre || !email || !telefono || !fecha || !hora || !personas) {
      return res.status(400).json({ mensaje: 'Todos los campos son obligatorios.' });
    }

    const [clientes] = await db.query('SELECT id FROM clientes WHERE email = ?', [email]);
    let cliente_id;

    if (clientes.length > 0) {
      cliente_id = clientes[0].id;
    } else {
      const [nuevo] = await db.query(
        'INSERT INTO clientes (nombre, email, telefono) VALUES (?, ?, ?)',
        [nombre, email, telefono]
      );
      cliente_id = nuevo.insertId;
    }

    const restaurante_id = 1; // Restaurante fijo
    const fecha_hora = `${fecha} ${hora}:00`; // formato DATETIME
    const num_personas = parseInt(personas);

    if (!num_personas || num_personas <= 0) {
      return res.status(400).json({ mensaje: 'Número de personas inválido.' });
    }

    // Verificar aforo disponible
    const [aforoRows] = await db.query(
      'SELECT aforo_actual, aforo_max FROM restaurantes WHERE id = ?',
      [restaurante_id]
    );

    if (aforoRows.length === 0) {
      return res.status(404).json({ mensaje: 'Restaurante no encontrado.' });
    }

    const { aforo_actual, aforo_max } = aforoRows[0];

    if (aforo_actual + num_personas > aforo_max) {
      return res.status(400).json({
        mensaje: `No hay suficiente aforo disponible. Solo quedan ${aforo_max - aforo_actual} plazas.`
      });
    }

    // Insertar la reserva
    const [reserva] = await db.query(
      'INSERT INTO reservas (cliente_id, restaurante_id, fecha_hora, num_personas) VALUES (?, ?, ?, ?)',
      [cliente_id, restaurante_id, fecha_hora, num_personas]
    );
    // Actualizar aforo_actual
    await db.query(
      'UPDATE restaurantes SET aforo_actual = aforo_actual + ? WHERE id = ?',
      [num_personas, restaurante_id]
    );

    res.status(201).json({
      mensaje: 'Reserva creada con éxito.',
      id: reserva.insertId
    });

  } catch (error) {
    console.error('Error en crearReserva:', error);
    res.status(500).json({ mensaje: 'Error interno del servidor.' });
  }
};
// Actualizar una reserva (personas y/o fecha y hora)
exports.actualizarReserva = async (req, res) => {
  try {
    const { id } = req.params;
    let { num_personas, fecha, hora } = req.body;

    const [rows] = await db.query('SELECT * FROM reservas WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ mensaje: 'Reserva no encontrada.' });
    }

    const reserva = rows[0];

    // usar valores actuales si no vienen datos nuevos
    const nueva_personas = num_personas !== undefined && num_personas !== '' ? parseInt(num_personas) : reserva.num_personas;
    const nueva_fecha = fecha && fecha.trim() !== '' ? fecha : reserva.fecha_hora.toISOString().split('T')[0];
    const nueva_hora = hora && hora.trim() !== '' ? hora : reserva.fecha_hora.toISOString().split('T')[1].substring(0, 5);

    if (isNaN(nueva_personas)) {
      return res.status(400).json({ mensaje: 'Número de personas inválido.' });
    }

    if (nueva_personas === 0) {
      await db.query('DELETE FROM reservas WHERE id = ?', [id]);
      return res.status(200).json({ mensaje: 'Reserva eliminada por establecer 0 personas.' });
    }

    const nueva_fecha_hora = `${nueva_fecha} ${nueva_hora}:00`;

    await db.query(
      'UPDATE reservas SET num_personas = ?, fecha_hora = ? WHERE id = ?',
      [nueva_personas, nueva_fecha_hora, id]
    );

    const diferencia = nueva_personas - reserva.num_personas;

if (diferencia !== 0) {
  await db.query(
    'UPDATE restaurantes SET aforo_actual = aforo_actual + ? WHERE id = ?',
    [diferencia, reserva.restaurante_id]
  );
}

    res.status(200).json({ mensaje: 'Reserva actualizada correctamente.' });
  } catch (error) {
    console.error('Error en actualizarReserva:', error);
    res.status(500).json({ mensaje: 'Error al actualizar la reserva.' });
  }
};

exports.eliminarReserva = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await db.query('SELECT * FROM reservas WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ mensaje: 'Reserva no encontrada.' });
    }

const personas = rows[0].num_personas;
const restaurante_id = rows[0].restaurante_id;

// Eliminar reserva
await db.query('DELETE FROM reservas WHERE id = ?', [id]);

// Restar del aforo
await db.query(
  'UPDATE restaurantes SET aforo_actual = aforo_actual - ? WHERE id = ?',
  [personas, restaurante_id]
);

res.status(200).json({ mensaje: 'Reserva cancelada correctamente.' });


  } catch (error) {
    console.error('Error en eliminarReserva:', error);
    res.status(500).json({ mensaje: 'Error al cancelar la reserva.' });
  }
};



// Obtener todas las reservas
exports.obtenerReservas = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM reservas');
    res.status(200).json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Error al obtener las reservas.' });
  }
};

// Obtener reserva por ID
exports.obtenerReservaPorId = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query('SELECT * FROM reservas WHERE id = ?', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ mensaje: 'Reserva no encontrada.' });
    }

    res.status(200).json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Error interno del servidor.' });
  }
};
