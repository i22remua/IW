// src/controllers/mesa.controller.js
const mysql = require('mysql2/promise');
require('dotenv').config();

// Configuración de la conexión a la base de datos
const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

// Crear Mesa
exports.crearMesa = async (req, res) => {
    try {
        const { numero, capacidad, restaurante_id } = req.body;

        if (!numero || !capacidad || !restaurante_id) {
            return res.status(400).json({ mensaje: 'Todos los campos son obligatorios.' });
        }

        const [result] = await db.query(
            'INSERT INTO mesas (numero, capacidad, restaurante_id) VALUES (?, ?, ?)',
            [numero, capacidad, restaurante_id]
        );

        res.status(201).json({ id: result.insertId, numero, capacidad, restaurante_id });
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};

// Obtener Mesas
exports.obtenerMesas = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM mesas');
        res.status(200).json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};

// Obtener Mesa por ID
exports.obtenerMesaPorId = async (req, res) => {
    try {
        const { id } = req.params;
        const [rows] = await db.query('SELECT * FROM mesas WHERE id = ?', [id]);

        if (rows.length === 0) {
            return res.status(404).json({ mensaje: 'Mesa no encontrada.' });
        }

        res.status(200).json(rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};

// Actualizar Mesa
exports.actualizarMesa = async (req, res) => {
    try {
        const { id } = req.params;
        const { numero, capacidad, restaurante_id } = req.body;

        if (!numero || !capacidad || !restaurante_id) {
            return res.status(400).json({ mensaje: 'Todos los campos son obligatorios.' });
        }

        await db.query(
            'UPDATE mesas SET numero = ?, capacidad = ?, restaurante_id = ? WHERE id = ?',
            [numero, capacidad, restaurante_id, id]
        );

        res.status(200).json({ mensaje: 'Mesa actualizada correctamente.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};

// Eliminar Mesa
exports.eliminarMesa = async (req, res) => {
    try {
        const { id } = req.params;
        await db.query('DELETE FROM mesas WHERE id = ?', [id]);
        res.status(200).json({ mensaje: 'Mesa eliminada correctamente.' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ mensaje: 'Error interno del servidor.' });
    }
};
