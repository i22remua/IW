// src/models/Reserva.js
const db = require('../config/database');

const Reserva = {
  getAll: (callback) => {
    db.query('SELECT * FROM reservas', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM reservas WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    const { cliente_id, mesa_id, fecha_reserva, numero_personas } = data;
    db.query(
      'INSERT INTO reservas (cliente_id, mesa_id, fecha_reserva, numero_personas) VALUES (?, ?, ?, ?)', 
      [cliente_id, mesa_id, fecha_reserva, numero_personas], 
      callback
    );
  },

  update: (id, data, callback) => {
    const { fecha_reserva, numero_personas } = data;
    db.query(
      'UPDATE reservas SET fecha_reserva = ?, numero_personas = ? WHERE id = ?', 
      [fecha_reserva, numero_personas, id], 
      callback
    );
  },

  delete: (id, callback) => {
    db.query('DELETE FROM reservas WHERE id = ?', [id], callback);
  }
};

module.exports = Reserva;
