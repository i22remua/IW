// src/models/HistorialAforo.js
const db = require('../config/database');

const HistorialAforo = {
  getAll: (callback) => {
    db.query('SELECT * FROM historial_aforo', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM historial_aforo WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    const { restaurante_id, fecha, aforo } = data;
    db.query(
      'INSERT INTO historial_aforo (restaurante_id, fecha, aforo) VALUES (?, ?, ?)', 
      [restaurante_id, fecha, aforo], 
      callback
    );
  },

  update: (id, data, callback) => {
    const { aforo } = data;
    db.query(
      'UPDATE historial_aforo SET aforo = ? WHERE id = ?', 
      [aforo, id], 
      callback
    );
  },

  delete: (id, callback) => {
    db.query('DELETE FROM historial_aforo WHERE id = ?', [id], callback);
  }
};

module.exports = HistorialAforo;
