const db = require('../config/database');

const Usuario = {
    getAll: (callback) => {
        db.query('SELECT * FROM usuarios', callback);
    },
    getById: (id, callback) => {
        db.query('SELECT * FROM usuarios WHERE id = ?', [id], callback);
    },
    create: (nombre, correo, contrasena, rol, callback) => {
        db.query(
            'INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES (?, ?, ?, ?)',
            [nombre, correo, contrasena, rol],
            callback
        );
    },
    update: (id, nombre, correo, contrasena, rol, callback) => {
        db.query(
            'UPDATE usuarios SET nombre = ?, correo = ?, contrasena = ?, rol = ? WHERE id = ?',
            [nombre, correo, contrasena, rol, id],
            callback
        );
    },
    delete: (id, callback) => {
        db.query('DELETE FROM usuarios WHERE id = ?', [id], callback);
    }
};

module.exports = Usuario;