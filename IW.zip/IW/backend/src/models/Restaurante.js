const db = require('../config/database');

const Restaurante = {
  getAll: (callback) => {
    db.query('SELECT * FROM restaurantes', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM restaurantes WHERE id = ?', [id], callback);
  },

  create: (nombre, direccion, tipo_comida, horario, aforo_max, historial, callback) => {
    db.query(
      'INSERT INTO restaurantes (nombre, direccion, tipo_comida, horario, aforo_max, historial) VALUES (?, ?, ?, ?, ?, ?)',
      [nombre, direccion, tipo_comida, horario, aforo_max, historial],
      callback
    );
  },

  update: (id, nombre, direccion, tipo_comida, horario, aforo_max, callback) => {
    db.query(
      'UPDATE restaurantes SET nombre = ?, direccion = ?, tipo_comida = ?, horario = ?, aforo_max = ? WHERE id = ?',
      [nombre, direccion, tipo_comida, horario, aforo_max, id],
      callback
    );
  },

  delete: (id, callback) => {
    db.query('DELETE FROM restaurantes WHERE id = ?', [id], callback);
  },

  // Incrementar aforo_actual
  incrementarAforo: (id, cantidad, callback) => {
    db.query(
      'UPDATE restaurantes SET aforo_actual = aforo_actual + ? WHERE id = ?',
      [cantidad, id],
      callback
    );
  }
};

module.exports = Restaurante;
