// src/models/Valoracion.js
const db = require('../config/database');

const Valoracion = {
  getAll: (callback) => {
    db.query('SELECT * FROM valoraciones', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM valoraciones WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    const { restaurante_id, usuario_id, puntuacion, comentario } = data;
    db.query(
      'INSERT INTO valoraciones (restaurante_id, usuario_id, puntuacion, comentario) VALUES (?, ?, ?, ?)', 
      [restaurante_id, usuario_id, puntuacion, comentario], 
      callback
    );
  },

  update: (id, data, callback) => {
    const { puntuacion, comentario } = data;
    db.query(
      'UPDATE valoraciones SET puntuacion = ?, comentario = ? WHERE id = ?', 
      [puntuacion, comentario, id], 
      callback
    );
  },

  delete: (id, callback) => {
    db.query('DELETE FROM valoraciones WHERE id = ?', [id], callback);
  }
};

module.exports = Valoracion;
