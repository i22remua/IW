// src/models/Mesa.js
const db = require('../config/database');

const Mesa = {
  getAll: (callback) => {
    db.query('SELECT * FROM mesas', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM mesas WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    const { numero, capacidad, restaurante_id } = data;
    db.query('INSERT INTO mesas (numero, capacidad, restaurante_id) VALUES (?, ?, ?)', 
      [numero, capacidad, restaurante_id], 
      callback);
  },

  update: (id, data, callback) => {
    const { numero, capacidad } = data;
    db.query('UPDATE mesas SET numero = ?, capacidad = ? WHERE id = ?', 
      [numero, capacidad, id], 
      callback);
  },

  delete: (id, callback) => {
    db.query('DELETE FROM mesas WHERE id = ?', [id], callback);
  }
};

module.exports = Mesa;
