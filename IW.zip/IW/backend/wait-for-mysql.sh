#!/bin/sh

echo "⏳ Esperando a que MySQL esté disponible en $DB_HOST:$DB_PORT..."

while ! mysqladmin ping -h"$DB_HOST" -P"$DB_PORT" --silent; do
  sleep 2
done

echo "✅ MySQL está disponible. Iniciando backend..."
exec "$@"
